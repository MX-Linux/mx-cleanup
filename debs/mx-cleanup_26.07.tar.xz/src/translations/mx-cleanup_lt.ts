<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="lt">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="196"/>
        <location filename="../mainwindow.cpp" line="1349"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="565"/>
        <source>MX Cleanup</source>
        <translation>MX išvalymas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="683"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="619"/>
        <source>Display help </source>
        <translation>Rodyti žinyną</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="686"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="621"/>
        <source>Help</source>
        <translation>Žinynas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="692"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="623"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="658"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="612"/>
        <source>About this application</source>
        <translation>Apie šią programą</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="24"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="603"/>
        <source>Main</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="531"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="602"/>
        <source>Purge residual configurations from removed packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="539"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="610"/>
        <source>Tools</source>
        <translation>Įrankiai</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="545"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="604"/>
        <source>Removal Tools</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="583"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="607"/>
        <source>Remove MX manuals for languages other than system default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="661"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="614"/>
        <source>About...</source>
        <translation>Apie...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="667"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="616"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="781"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="631"/>
        <source>Quit application</source>
        <translation>Išeiti iš programos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <location filename="../mainwindow.cpp" line="1532"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="633"/>
        <source>Close</source>
        <translation>Užverti</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="790"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="635"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="756"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="626"/>
        <source>Apply</source>
        <translation>Taikyti</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="36"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="566"/>
        <source>Empty Trash</source>
        <translation>Išvalyti šiukšlinę</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="45"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="567"/>
        <source>Trash older than:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="103"/>
        <location filename="../mainwindow.ui" line="294"/>
        <location filename="../mainwindow.ui" line="438"/>
        <location filename="../mainwindow.cpp" line="910"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="570"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="584"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="592"/>
        <source> days</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="58"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="568"/>
        <source>All users</source>
        <translation>Visi naudotojai</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="90"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="569"/>
        <source>Selected user</source>
        <translation>Pasirinktas naudotojas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="210"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="579"/>
        <source>Clear APT Cache</source>
        <translation>Išvalyti APT podėlį</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="580"/>
        <source>Old files</source>
        <translation>Seni failai</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="244"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="581"/>
        <source>All files</source>
        <translation>Visi failai</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="605"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="608"/>
        <source>Graphical Tool for Analyzing Disk Usage</source>
        <translation>Grafinis įrankis, skirtas disko naudojimo analizavimui</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="617"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="609"/>
        <source>Run Disk Usage Analyzer</source>
        <translation>Paleisti disko naudojimo analizatorių</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="141"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="573"/>
        <source>Schedule</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="153"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="574"/>
        <source>No automatic clean</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="575"/>
        <source>At reboot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="167"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="576"/>
        <source>Daily</source>
        <translation>Kasdien</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="174"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="577"/>
        <source>Weekly</source>
        <translation>Kas savaitę</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="578"/>
        <source>Monthly</source>
        <translation>Kas mėnesį</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="467"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="594"/>
        <source>Free Disk Space for User</source>
        <translation>Atlaisvinti naudotojui vietą diske</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="479"/>
        <location filename="../mainwindow.ui" line="495"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="596"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="600"/>
        <source>Select user to repair</source>
        <translation>Pasirinkite naudotoją, kurį pataisyti</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="482"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="598"/>
        <source>Select user:</source>
        <translation>Pasirinkite naudotoją:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="263"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="582"/>
        <source>Delete Logs</source>
        <translation>Ištrinti žurnalus</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="278"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="583"/>
        <source>All logs</source>
        <translation>Visi žurnalai</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="339"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="587"/>
        <source>Old logs</source>
        <translation>Seni žurnalai</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="326"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="586"/>
        <source>Logs older than:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="551"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="605"/>
        <source>Remove unused WiFi drivers</source>
        <translation>Šalinti nenaudojamas belaidžio ryšio (WiFi) tvarkykles</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="570"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="606"/>
        <source>List and select kernels to remove</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="125"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="571"/>
        <source>Clean Flatpak</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="572"/>
        <source>Remove unused runtimes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="364"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="588"/>
        <source>Clean Folders</source>
        <translation>Aplankai, kuriuos išvalyti</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="428"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="591"/>
        <source>Not accessed for:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="376"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="589"/>
        <source>Cache</source>
        <translation>Podėlis</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="451"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="593"/>
        <source>All (potentially dangerous)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="405"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="590"/>
        <source>Thumbnails</source>
        <translation>Miniatiūros</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="139"/>
        <source>Remove Manuals</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="139"/>
        <source>No manuals to remove.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="151"/>
        <location filename="../mainwindow.cpp" line="158"/>
        <source>Removing packages, please wait</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="910"/>
        <source> day</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="144"/>
        <location filename="../mainwindow.cpp" line="748"/>
        <location filename="../mainwindow.cpp" line="761"/>
        <location filename="../mainwindow.cpp" line="922"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="216"/>
        <source>Clean pacman cache</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="749"/>
        <source>Failed to create temporary cron file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="762"/>
        <source>Failed to create temporary script file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="144"/>
        <location filename="../mainwindow.cpp" line="922"/>
        <source>Failed to elevate privileges</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1337"/>
        <source>Done</source>
        <translation>Atlikta</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1339"/>
        <source>Cleanup script will run at reboot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1340"/>
        <source>Cleanup command done</source>
        <translation>Išvalymo komanda atlikta</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1341"/>
        <source>%1 MiB were freed</source>
        <translation>Buvo atlaisvinta %1 MiB</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1349"/>
        <source>About</source>
        <translation>Apie</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1350"/>
        <source>Version: </source>
        <translation>Versija: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1352"/>
        <source>Quick and safe removal of old files</source>
        <translation>Greitas ir saugus senų failų šalinimas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1354"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Autorių teisės (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1355"/>
        <source>%1 License</source>
        <translation>%1 licencija</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1362"/>
        <source>%1 Help</source>
        <translation>%1 žinynas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1527"/>
        <source>Kernel currently in use: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Šiuo metu naudojamas branduolys: &lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1530"/>
        <source>Remove selected</source>
        <translation>Šalinti pažymėtus</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1535"/>
        <source>Similar kernels that can be removed:</source>
        <translation>Panašūs branduoliai, kurie gali būti pašalinti:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1536"/>
        <source>Other kernels that can be removed:</source>
        <translation>Kiti branduoliai, kurie gali būti pašalinti:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1539"/>
        <source>&lt;b&gt;Nothing to remove.&lt;/b&gt; Cannot remove kernel in use.</source>
        <translation>&lt;b&gt;Nėra, ką šalinti.&lt;/b&gt; Negalima šalinti naudojamo branduolio.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1583"/>
        <source>Info</source>
        <translation>Informacija</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1583"/>
        <source>No unused network drivers found to remove.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>Nepavyko įkelti %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="94"/>
        <source>License</source>
        <translation>Licencija</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="95"/>
        <location filename="../about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Keitinių žurnalas</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Atsisakyti</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>Nepavyko įkelti keitinių žurnalo.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="51"/>
        <location filename="../about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Užverti</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="63"/>
        <source>Quick safe removal of old files</source>
        <translation>Greitas ir saugus senų failų šalinimas</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="89"/>
        <location filename="../main.cpp" line="97"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="90"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../main.cpp" line="98"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>