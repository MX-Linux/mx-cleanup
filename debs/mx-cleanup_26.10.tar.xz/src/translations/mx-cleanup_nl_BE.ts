<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nl_BE">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="201"/>
        <location filename="../mainwindow.cpp" line="1253"/>
        <source>MX Cleanup</source>
        <translation>MX Opruimen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="683"/>
        <source>Display help </source>
        <translation>Toon help</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="686"/>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="692"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="658"/>
        <source>About this application</source>
        <translation>Over deze applicatie</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="24"/>
        <source>Main</source>
        <translation>Hoofd</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="531"/>
        <source>Purge residual configurations from removed packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="539"/>
        <source>Tools</source>
        <translation>Gereedschap</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="545"/>
        <source>Removal Tools</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="583"/>
        <source>Remove MX manuals for languages other than system default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="661"/>
        <source>About...</source>
        <translation>Over...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="667"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="781"/>
        <source>Quit application</source>
        <translation>Verlaat de applicatie</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <location filename="../mainwindow.cpp" line="1514"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="790"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="756"/>
        <source>Apply</source>
        <translation>Toepassen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="36"/>
        <source>Empty Trash</source>
        <translation>Prullenbak Legen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="45"/>
        <source>Trash older than:</source>
        <translation>Afval ouder dan:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="103"/>
        <location filename="../mainwindow.ui" line="294"/>
        <location filename="../mainwindow.ui" line="438"/>
        <location filename="../mainwindow.cpp" line="877"/>
        <source> days</source>
        <translation>dagen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="58"/>
        <source>All users</source>
        <translation>Alle gebruikers</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="90"/>
        <source>Selected user</source>
        <translation>Selecteer gebruiker</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="210"/>
        <source>Clear APT Cache</source>
        <translation>Ruim Apt Cache op</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <source>Old files</source>
        <translation>Oude bestanden</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="244"/>
        <source>All files</source>
        <translation>Alle bestanden</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="605"/>
        <source>Graphical Tool for Analyzing Disk Usage</source>
        <translation>Grafisch Gereedschap voor het Analyseren van Schijfgebruik</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="617"/>
        <source>Run Disk Usage Analyzer</source>
        <translation>Schijfgebruik Analyse</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="141"/>
        <source>Schedule</source>
        <translation>Schema</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="153"/>
        <source>No automatic clean</source>
        <translation>Geen automatische schoonmaak</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <source>At reboot</source>
        <translation>Bij herstarten</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="167"/>
        <source>Daily</source>
        <translation>Dagelijks</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="174"/>
        <source>Weekly</source>
        <translation>Wekelijks</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <source>Monthly</source>
        <translation>Maandelijks</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="467"/>
        <source>Free Disk Space for User</source>
        <translation>Vrije Schijfruimte voor Gebruiker</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="479"/>
        <location filename="../mainwindow.ui" line="495"/>
        <source>Select user to repair</source>
        <translation>Selecteer een gebruiker voor reparatie</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="482"/>
        <source>Select user:</source>
        <translation>Selecteer gebruiker:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="263"/>
        <source>Delete Logs</source>
        <translation>Verwijder Logs</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="278"/>
        <source>All logs</source>
        <translation>Alle logs</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="339"/>
        <source>Old logs</source>
        <translation>Oude logs</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="326"/>
        <source>Logs older than:</source>
        <translation>Logs ouder dan:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="551"/>
        <source>Remove unused WiFi drivers</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="570"/>
        <source>List and select kernels to remove</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="125"/>
        <source>Clean Flatpak</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <source>Remove unused runtimes</source>
        <translation>Ongebruikte looptijden verwijderen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="364"/>
        <source>Clean Folders</source>
        <translation>Folders om te Schonen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="428"/>
        <source>Not accessed for:</source>
        <translation>Niet toegankelijk voor:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="376"/>
        <source>Cache</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="451"/>
        <source>All (potentially dangerous)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="405"/>
        <source>Thumbnails</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="142"/>
        <source>Remove Manuals</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="142"/>
        <source>No manuals to remove.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="155"/>
        <location filename="../mainwindow.cpp" line="162"/>
        <source>Removing packages, please wait</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="877"/>
        <source> day</source>
        <translation>dagen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="148"/>
        <location filename="../mainwindow.cpp" line="890"/>
        <source>Error</source>
        <translation>Foutmelding</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="221"/>
        <source>Clean pacman cache</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="148"/>
        <location filename="../mainwindow.cpp" line="890"/>
        <source>Failed to elevate privileges</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="939"/>
        <location filename="../mainwindow.cpp" line="961"/>
        <source>Cache cleanup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="991"/>
        <location filename="../mainwindow.cpp" line="995"/>
        <source>Thumbnail cleanup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1016"/>
        <location filename="../mainwindow.cpp" line="1034"/>
        <source>Flatpak cleanup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1070"/>
        <source>Package cache cleanup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1095"/>
        <source>Package purge</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1119"/>
        <source>Log cleanup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1153"/>
        <location filename="../mainwindow.cpp" line="1157"/>
        <source>Trash cleanup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1214"/>
        <source>Save cleanup schedule</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1217"/>
        <source>Remove previous cleanup schedule</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1221"/>
        <source>Save settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1237"/>
        <source>Some cleanup steps failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1238"/>
        <source>%1 MiB were freed, but the following steps failed:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1241"/>
        <location filename="../mainwindow.cpp" line="1243"/>
        <source>Done</source>
        <translation>Klaar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1241"/>
        <source>Cleanup script will run at reboot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1244"/>
        <source>Cleanup command done</source>
        <translation>Opruim commando klaar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1244"/>
        <source>%1 MiB were freed</source>
        <translation>%1 MiB werd vrijgemaakt</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1253"/>
        <source>About</source>
        <translation>Over</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1254"/>
        <source>Version: </source>
        <translation>Versie:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1256"/>
        <source>Quick and safe removal of old files</source>
        <translation>Snelle en veilige verwijdering van oude bestanden</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1258"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1259"/>
        <source>%1 License</source>
        <translation>%1 Licentie</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1266"/>
        <source>%1 Help</source>
        <translation>%1 Help</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1378"/>
        <source>No privilege elevation tool is available</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1391"/>
        <source>Failed to start the helper process</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1414"/>
        <source>Operation timed out</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1509"/>
        <source>Kernel currently in use: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Kernel momenteel in gebruik:&lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1512"/>
        <source>Remove selected</source>
        <translation>Verwijder geselecteerde</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1517"/>
        <source>Similar kernels that can be removed:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1518"/>
        <source>Other kernels that can be removed:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1521"/>
        <source>&lt;b&gt;Nothing to remove.&lt;/b&gt; Cannot remove kernel in use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1565"/>
        <location filename="../mainwindow.cpp" line="1578"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1565"/>
        <source>No unused network drivers found to remove.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1578"/>
        <source>No valid packages found to remove.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../about.cpp" line="94"/>
        <source>License</source>
        <translation>Licentie</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="95"/>
        <location filename="../about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Changelog</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../about.cpp" line="51"/>
        <location filename="../about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Sluiten</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="63"/>
        <source>Quick safe removal of old files</source>
        <translation>Snelle en veilige verwijdering van oude bestanden</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="92"/>
        <location filename="../main.cpp" line="100"/>
        <source>Error</source>
        <translation>Foutmelding</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>U lijkt ingelogd te zijn als root, gelieve uit te loggen en in te loggen als normale gebruiker om dit programma te gebruiken.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="101"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>