<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sl">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="81"/>
        <location filename="../mainwindow.cpp" line="502"/>
        <source>MX Cleanup</source>
        <translation>MX Čiščenje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>Display help </source>
        <translation>Prikaži pomoč</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="62"/>
        <source>Help</source>
        <translation>Pomoč</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="69"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="98"/>
        <source>About this application</source>
        <translation>O tem programu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="101"/>
        <source>About...</source>
        <translation>O programu...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="108"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="140"/>
        <source>Quit application</source>
        <translation>Zapri aplikacijo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="143"/>
        <location filename="../mainwindow.cpp" line="586"/>
        <source>Close</source>
        <translation>Zapri</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="150"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="188"/>
        <source>Apply</source>
        <translation>Potrdi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="216"/>
        <source>Empty Trash</source>
        <translation>Izprazni smeti</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="222"/>
        <source>Trash older than:</source>
        <translation>V smeti premakni starejše od:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="235"/>
        <location filename="../mainwindow.ui" line="372"/>
        <location filename="../mainwindow.ui" line="590"/>
        <source>Don&apos;t empty</source>
        <translation>Ne briši</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="245"/>
        <location filename="../mainwindow.ui" line="622"/>
        <location filename="../mainwindow.ui" line="724"/>
        <location filename="../mainwindow.cpp" line="364"/>
        <location filename="../mainwindow.cpp" line="367"/>
        <location filename="../mainwindow.cpp" line="371"/>
        <source> days</source>
        <translation>dni</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="264"/>
        <source>All users</source>
        <translation>Vsi uporabniki</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="283"/>
        <source>Selected user</source>
        <translation>Izbrani uporabnik</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="331"/>
        <source>Clear APT Cache</source>
        <translation>Očisti medpomnilnik APT</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="343"/>
        <source>Old files</source>
        <translation>Stare datoteke</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="362"/>
        <source>All files</source>
        <translation>Vse datoteke</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="404"/>
        <source>Graphical Tool for Analyzing Disk Usage</source>
        <translation>Grafično orodje za analiziranje rabe diska</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="416"/>
        <source>Run Disk Usage Analyzer</source>
        <translation>Zaženi analizo rabe diska</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="430"/>
        <source>Schedule</source>
        <translation>Razpored</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="442"/>
        <source>No automatic clean</source>
        <translation>Brez samodejnega čiščenja</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="449"/>
        <source>At reboot</source>
        <translation>Ob zagonu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="456"/>
        <source>Daily</source>
        <translation>Dnevno</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="463"/>
        <source>Weekly</source>
        <translation>Tedensko</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="470"/>
        <source>Monthly</source>
        <translation>Mesečno</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="499"/>
        <source>Free Disk Space for User</source>
        <translation>Sprosti prostor na disku za uporabnika</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="511"/>
        <location filename="../mainwindow.ui" line="527"/>
        <source>Select user to repair</source>
        <translation>Izberi uporabnika za popravilo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="514"/>
        <source>Select user:</source>
        <translation>Izberi uporabnika:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="543"/>
        <source>Delete Logs</source>
        <translation>Izbriši dnevnike</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="568"/>
        <source>All logs</source>
        <translation>Vsi dnevniki</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="606"/>
        <source>Old logs</source>
        <translation>Stari dnevniki</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="641"/>
        <source>Logs older than:</source>
        <translation>Dnevnike starejše od:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="664"/>
        <source>Kernel removal tool</source>
        <translation>Orodje za odstranitev jedra</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="676"/>
        <source>List and select kernels to remove</source>
        <translation>Prikaz in izbira jeder za odstranitev</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="696"/>
        <source>Clean Flatpak</source>
        <translation>Čisti Flatpak</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="702"/>
        <source>Remove unused runtimes</source>
        <translation>Odstrani neuporabljene zagone</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="718"/>
        <source>Clean Folders</source>
        <translation>Počisti mape</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="737"/>
        <source>Not accessed for:</source>
        <translation>Ni bil v uporabi:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="805"/>
        <source>All (potentially dangerous)</source>
        <translation>Vse (je lahko nevarno)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="206"/>
        <source>Press any key to close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="364"/>
        <location filename="../mainwindow.cpp" line="368"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <source> day</source>
        <translation>dni</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="494"/>
        <source>Done</source>
        <translation>Zaključeno</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="495"/>
        <source>Cleanup command done</source>
        <translation>Čiščenje je končano</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="495"/>
        <source>%1 MiB were freed</source>
        <translation>%1 MiB je bilo sproščeno</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="502"/>
        <source>About</source>
        <translation>O programu</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="503"/>
        <source>Version: </source>
        <translation>Različica:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="505"/>
        <source>Quick and safe removal of old files</source>
        <translation>Hitro in varno odstranjevanje starih datotek</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="507"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="508"/>
        <source>%1 License</source>
        <translation>%1 licenca</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="515"/>
        <source>%1 Help</source>
        <translation>%1 pomoč</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="581"/>
        <source>Kernel currently in use: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Trenutno uporabljeno jedro: &lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="584"/>
        <source>Remove selected</source>
        <translation>Odstrani izbrane</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>Similar kernels that can be removed:</source>
        <translation>Podobna jedra, ki jih je mogoče odstraniti:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="590"/>
        <source>Other kernels that can be removed:</source>
        <translation>Druga jedra, ki jih je mogoče odstraniti:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="592"/>
        <source>&lt;b&gt;Nothing to remove.&lt;/b&gt; Cannot remove kernel in use.</source>
        <translation>&lt;b&gt;Ničesar ni za odstraniti.&lt;/b&gt; Ne morem odtrsaniti jedra, ki je v rabi.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="51"/>
        <source>License</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="52"/>
        <location filename="../about.cpp" line="62"/>
        <source>Changelog</source>
        <translation>Dnevnik sprememb</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="53"/>
        <source>Cancel</source>
        <translation>Prekliči</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="75"/>
        <source>&amp;Close</source>
        <translation>&amp;Zapri</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="54"/>
        <source>Quick safe removal of old files</source>
        <translation>Hitro varno odstranjevanje starih datotek</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="81"/>
        <location filename="../main.cpp" line="89"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="82"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Prijevljeni ste kot korenski uporabnik. Izpišite se in se ponovno prijavite kot običajen uporabnik, če želite uporabljati ta program.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="90"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
