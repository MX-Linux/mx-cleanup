<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="81"/>
        <location filename="../mainwindow.cpp" line="507"/>
        <source>MX Cleanup</source>
        <translation>MX Limpieza</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="62"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="69"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="98"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="101"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="108"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="140"/>
        <source>Quit application</source>
        <translation>Terminar aplicación</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="143"/>
        <location filename="../mainwindow.cpp" line="591"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="150"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="188"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="216"/>
        <source>Empty Trash</source>
        <translation>Vaciar papelera</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="222"/>
        <source>Trash older than:</source>
        <translation>Basura anterior a:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="235"/>
        <location filename="../mainwindow.ui" line="372"/>
        <location filename="../mainwindow.ui" line="590"/>
        <source>Don&apos;t empty</source>
        <translation>No vaciar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="245"/>
        <location filename="../mainwindow.ui" line="622"/>
        <location filename="../mainwindow.ui" line="796"/>
        <location filename="../mainwindow.cpp" line="369"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="376"/>
        <source> days</source>
        <translation>días</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="264"/>
        <source>All users</source>
        <translation>Todos los usuarios</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="283"/>
        <source>Selected user</source>
        <translation>Usuario seleccionado</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="331"/>
        <source>Clear APT Cache</source>
        <translation>Limpiar Cache de APT</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="343"/>
        <source>Old files</source>
        <translation>Ficheros viejos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="362"/>
        <source>All files</source>
        <translation>Todos los ficheros</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="404"/>
        <source>Graphical Tool for Analyzing Disk Usage</source>
        <translation>Herramienta gráfica para Analizar Utilización del Disco</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="416"/>
        <source>Run Disk Usage Analyzer</source>
        <translation>Ejecuta Analizador de Utilización del Disco</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="430"/>
        <source>Schedule</source>
        <translation>Horario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="442"/>
        <source>No automatic clean</source>
        <translation>No ejecutar limpieza automática</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="449"/>
        <source>At reboot</source>
        <translation>Al reiniciar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="456"/>
        <source>Daily</source>
        <translation>Diario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="463"/>
        <source>Weekly</source>
        <translation>Semanal</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="470"/>
        <source>Monthly</source>
        <translation>Mensual</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="499"/>
        <source>Free Disk Space for User</source>
        <translation>Espacio Libre en Disco para Usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="511"/>
        <location filename="../mainwindow.ui" line="527"/>
        <source>Select user to repair</source>
        <translation>Seleccione el usuario a reparar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="514"/>
        <source>Select user:</source>
        <translation>Seleccionar usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="543"/>
        <source>Delete Logs</source>
        <translation>Borrar Registros</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="568"/>
        <source>All logs</source>
        <translation>Todos los registros</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="606"/>
        <source>Old logs</source>
        <translation>Registros viejos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="641"/>
        <source>Logs older than:</source>
        <translation>Registros anteriores a:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="664"/>
        <source>Removal tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="670"/>
        <source>Remove unused RTL drivers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Kernel removal tool</source>
        <translation type="vanished">Herramienta de eliminación de kernel</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="686"/>
        <source>List and select kernels to remove</source>
        <translation>Enlista y selecciona kernels para remover</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="706"/>
        <source>Clean Flatpak</source>
        <translation>Limpiar Flatpak</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="712"/>
        <source>Remove unused runtimes</source>
        <translation>Eliminar los tiempos de ejecución no usados</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="728"/>
        <source>Clean Folders</source>
        <translation>Limpiar carpetas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="734"/>
        <source>Not accessed for:</source>
        <translation>No accedido por:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="776"/>
        <source>All (potentially dangerous)</source>
        <translation>Todos (potencialmente peligrosos)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="207"/>
        <location filename="../mainwindow.cpp" line="626"/>
        <source>Press any key to close</source>
        <translation>Pulse cualquier tecla para cerrar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="369"/>
        <location filename="../mainwindow.cpp" line="373"/>
        <location filename="../mainwindow.cpp" line="377"/>
        <source> day</source>
        <translation>día</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="499"/>
        <source>Done</source>
        <translation>Listo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="500"/>
        <source>Cleanup command done</source>
        <translation>Comando de limpieza listo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="500"/>
        <source>%1 MiB were freed</source>
        <translation>%1 MiB liberado</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="507"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="508"/>
        <source>Version: </source>
        <translation>Versión:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="510"/>
        <source>Quick and safe removal of old files</source>
        <translation>Remoción de ficheros viejos, rápido y seguro</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="512"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="520"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="586"/>
        <source>Kernel currently in use: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Kernel actualmente en uso: &lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>Remove selected</source>
        <translation>Eliminar selección</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="594"/>
        <source>Similar kernels that can be removed:</source>
        <translation>Kernels similares que se pueden remover:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="595"/>
        <source>Other kernels that can be removed:</source>
        <translation>Otros kernels que se pueden remover:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="597"/>
        <source>&lt;b&gt;Nothing to remove.&lt;/b&gt; Cannot remove kernel in use.</source>
        <translation>&lt;b&gt;Nada que remover.&lt;/b&gt; No se puede remover el kernel en uso.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="50"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="51"/>
        <location filename="../about.cpp" line="61"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="52"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="74"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="53"/>
        <source>Quick safe removal of old files</source>
        <translation>Eliminación rápida y segura de archivos antiguos</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="80"/>
        <location filename="../main.cpp" line="88"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="81"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que ha iniciado sesión como root, cierre la sesión e inicie sesión como usuario normal para utilizar este programa.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="89"/>
        <source>You must run this program with admin access.</source>
        <translation>Debe ejecutar este programa con acceso de administrador.</translation>
    </message>
</context>
</TS>
