<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="202"/>
        <location filename="../mainwindow.cpp" line="1365"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="565"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="565"/>
        <source>MX Cleanup</source>
        <translation>MX Limpiador</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="683"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="619"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="619"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="686"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="621"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="621"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="692"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="623"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="623"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="658"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="612"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="612"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="24"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="603"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="603"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="531"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="602"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="602"/>
        <source>Purge residual configurations from removed packages</source>
        <translation>Eliminar la configuración residual de los paquetes eliminados</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="539"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="610"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="610"/>
        <source>Tools</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="545"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="604"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="604"/>
        <source>Removal Tools</source>
        <translation>Herramientas de eliminación</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="583"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="607"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="607"/>
        <source>Remove MX manuals for languages other than system default</source>
        <translation>Eliminar los manuales MX para idiomas distintos del predeterminado del sistema</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="661"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="614"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="614"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="667"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="616"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="616"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="781"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="631"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="631"/>
        <source>Quit application</source>
        <translation>Salir de la aplicación</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <location filename="../mainwindow.cpp" line="1626"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="633"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="633"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="790"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="635"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="635"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="756"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="626"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="626"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="36"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="566"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="566"/>
        <source>Empty Trash</source>
        <translation>Vaciar papelera</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="45"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="567"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="567"/>
        <source>Trash older than:</source>
        <translation>Papelera anterior a:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="103"/>
        <location filename="../mainwindow.ui" line="294"/>
        <location filename="../mainwindow.ui" line="438"/>
        <location filename="../mainwindow.cpp" line="967"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="570"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="584"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="592"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="570"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="584"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="592"/>
        <source> days</source>
        <translation> días</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="58"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="568"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="568"/>
        <source>All users</source>
        <translation>Todos los usuarios</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="90"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="569"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="569"/>
        <source>Selected user</source>
        <translation>Usuario seleccionado</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="210"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="579"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="579"/>
        <source>Clear APT Cache</source>
        <translation>Limpiar Cache de APT</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="580"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="580"/>
        <source>Old files</source>
        <translation>Archivos antiguos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="244"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="581"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="581"/>
        <source>All files</source>
        <translation>Todos los archivos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="605"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="608"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="608"/>
        <source>Graphical Tool for Analyzing Disk Usage</source>
        <translation>Herramienta gráfica para Analizar el Uso del Disco</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="617"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="609"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="609"/>
        <source>Run Disk Usage Analyzer</source>
        <translation>Ejecutar Analizador de Uso del Disco</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="141"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="573"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="573"/>
        <source>Schedule</source>
        <translation>Programar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="153"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="574"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="574"/>
        <source>No automatic clean</source>
        <translation>Sin limpieza automática</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="575"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="575"/>
        <source>At reboot</source>
        <translation>Al reiniciar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="167"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="576"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="576"/>
        <source>Daily</source>
        <translation>Diariamente</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="174"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="577"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="577"/>
        <source>Weekly</source>
        <translation>Semanalmente</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="578"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="578"/>
        <source>Monthly</source>
        <translation>Mensualmente</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="467"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="594"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="594"/>
        <source>Free Disk Space for User</source>
        <translation>Espacio Libre en Disco para el Usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="479"/>
        <location filename="../mainwindow.ui" line="495"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="596"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="600"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="596"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="600"/>
        <source>Select user to repair</source>
        <translation>Seleccione el usuario a reparar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="482"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="598"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="598"/>
        <source>Select user:</source>
        <translation>Seleccionar usuario:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="263"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="582"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="582"/>
        <source>Delete Logs</source>
        <translation>Borrar Registros</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="278"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="583"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="583"/>
        <source>All logs</source>
        <translation>Todos los registros</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="339"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="587"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="587"/>
        <source>Old logs</source>
        <translation>Registros antiguos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="326"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="586"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="586"/>
        <source>Logs older than:</source>
        <translation>Registros anteriores a:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="551"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="605"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="605"/>
        <source>Remove unused WiFi drivers</source>
        <translation>Eliminar controladores de WiFi no utilizados</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="570"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="606"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="606"/>
        <source>List and select kernels to remove</source>
        <translation>Lista y selección de los kerneles a eliminar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="125"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="571"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="571"/>
        <source>Clean Flatpak</source>
        <translation>Limpiar Flatpak</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="572"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="572"/>
        <source>Remove unused runtimes</source>
        <translation>Eliminar los ejecutables no usados</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="364"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="588"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="588"/>
        <source>Clean Folders</source>
        <translation>Limpiar Carpetas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="428"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="591"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="591"/>
        <source>Not accessed for:</source>
        <translation>No accesible por</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="376"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="589"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="589"/>
        <source>Cache</source>
        <translation>Cache</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="451"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="593"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="593"/>
        <source>All (potentially dangerous)</source>
        <translation>Todos (potencialmente peligroso)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="405"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="590"/>
        <location filename="../build/test_mx-cleanup_autogen/include/ui_mainwindow.h" line="590"/>
        <source>Thumbnails</source>
        <translation>Imágenes en miniatura</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="143"/>
        <source>Remove Manuals</source>
        <translation>Eliminar manuales</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="143"/>
        <source>No manuals to remove.</source>
        <translation>No hay manuales que eliminar.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="156"/>
        <location filename="../mainwindow.cpp" line="163"/>
        <source>Removing packages, please wait</source>
        <translation>Eliminando paquetes, por favor espere</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="967"/>
        <source> day</source>
        <translation>día</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="149"/>
        <location filename="../mainwindow.cpp" line="986"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="222"/>
        <source>Clean pacman cache</source>
        <translation>Limpiar la caché de Pacman</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="149"/>
        <location filename="../mainwindow.cpp" line="986"/>
        <source>Failed to elevate privileges</source>
        <translation>No se pudieron elevar los privilegios</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1038"/>
        <location filename="../mainwindow.cpp" line="1060"/>
        <source>Cache cleanup</source>
        <translation>Limpieza de la caché</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1090"/>
        <location filename="../mainwindow.cpp" line="1094"/>
        <source>Thumbnail cleanup</source>
        <translation>Limpieza de miniaturas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1115"/>
        <location filename="../mainwindow.cpp" line="1133"/>
        <source>Flatpak cleanup</source>
        <translation>Limpieza de Flatpak</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1169"/>
        <source>Package cache cleanup</source>
        <translation>Limpieza de la caché de paquetes</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1195"/>
        <source>Package purge</source>
        <translation>Purgado de paquetes</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1221"/>
        <source>Log cleanup</source>
        <translation>Limpieza de registros</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1258"/>
        <location filename="../mainwindow.cpp" line="1262"/>
        <source>Trash cleanup</source>
        <translation>Limpieza de la Papelera</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1312"/>
        <location filename="../mainwindow.cpp" line="1326"/>
        <source>Save cleanup schedule</source>
        <translation>Guardar el calendario de limpieza</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1329"/>
        <source>Remove previous cleanup schedule</source>
        <translation>Eliminar el calendario de limpieza anterior</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1333"/>
        <source>Save settings</source>
        <translation>Guardar ajustes</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1349"/>
        <source>Some cleanup steps failed</source>
        <translation>Algunos pasos de la limpieza han fallado</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1350"/>
        <source>%1 MiB were freed, but the following steps failed:</source>
        <translation>Se han liberado %1 MiB, pero los siguientes pasos han fallado:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1353"/>
        <location filename="../mainwindow.cpp" line="1355"/>
        <source>Done</source>
        <translation>Hecho</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1353"/>
        <source>Cleanup script will run at reboot</source>
        <translation>El script de limpieza se ejecutará al reiniciar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1356"/>
        <source>Cleanup command done</source>
        <translation>Orden de limpieza hecha</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1356"/>
        <source>%1 MiB were freed</source>
        <translation>%1 MiB fueron liberados</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1365"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1366"/>
        <source>Version: </source>
        <translation>Versión: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1368"/>
        <source>Quick and safe removal of old files</source>
        <translation>Eliminación rápida y segura de archivos antiguos</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1370"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1371"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1378"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1490"/>
        <source>No privilege elevation tool is available</source>
        <translation>No hay ninguna herramienta de elevación de privilegios disponible.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1503"/>
        <source>Failed to start the helper process</source>
        <translation>No se pudo iniciar el proceso auxiliar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1526"/>
        <source>Operation timed out</source>
        <translation>La operación ha superado el tiempo de espera</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1621"/>
        <source>Kernel currently in use: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Kernel actualmente en uso: &lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1624"/>
        <source>Remove selected</source>
        <translation>Eliminar lo seleccionado</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1629"/>
        <source>Similar kernels that can be removed:</source>
        <translation>Kerneles similares que pueden eliminarse:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1630"/>
        <source>Other kernels that can be removed:</source>
        <translation>Otros kerneles que pueden eliminarse:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1633"/>
        <source>&lt;b&gt;Nothing to remove.&lt;/b&gt; Cannot remove kernel in use.</source>
        <translation>&lt;b&gt;Nada que eliminar.&lt;/b&gt; No puede eliminarse el kernel en uso.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1677"/>
        <location filename="../mainwindow.cpp" line="1690"/>
        <source>Info</source>
        <translation>Informacion</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1677"/>
        <source>No unused network drivers found to remove.</source>
        <translation>No se han encontrado controladores de red no utilizados para eliminar.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1690"/>
        <source>No valid packages found to remove.</source>
        <translation>No se encontraron paquetes válidos para eliminar.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>No se pudo cargar %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="94"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="95"/>
        <location filename="../about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>No se pudo cargar el registro de cambios.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="51"/>
        <location filename="../about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="70"/>
        <source>Quick safe removal of old files</source>
        <translation>Eliminación rápida y segura de archivos antiguos</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="99"/>
        <location filename="../main.cpp" line="107"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="100"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que ha iniciado sesión como root, cierre la sesión e inicie sesión como usuario normal para usar este programa.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>You must run this program with admin access.</source>
        <translation>Debe ejecutar este programa con acceso de administrador.</translation>
    </message>
</context>
</TS>