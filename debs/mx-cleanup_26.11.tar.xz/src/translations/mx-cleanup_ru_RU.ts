<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ru_RU">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="202"/>
        <location filename="../mainwindow.cpp" line="1360"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="565"/>
        <source>MX Cleanup</source>
        <translation>MX Очистка</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="683"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="619"/>
        <source>Display help </source>
        <translation>Показать справку</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="686"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="621"/>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="692"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="623"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="658"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="612"/>
        <source>About this application</source>
        <translation>Об этом приложении</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="24"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="603"/>
        <source>Main</source>
        <translation>Основные</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="531"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="602"/>
        <source>Purge residual configurations from removed packages</source>
        <translation>Очистить остаточные конфигурации удалённых пакетов</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="539"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="610"/>
        <source>Tools</source>
        <translation>Инструменты</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="545"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="604"/>
        <source>Removal Tools</source>
        <translation>Инструменты удаления</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="583"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="607"/>
        <source>Remove MX manuals for languages other than system default</source>
        <translation>Удалить руководства MX для языков, отличных от системного</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="661"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="614"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="667"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="616"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="781"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="631"/>
        <source>Quit application</source>
        <translation>Выйти из приложения</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <location filename="../mainwindow.cpp" line="1621"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="633"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="790"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="635"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="756"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="626"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="36"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="566"/>
        <source>Empty Trash</source>
        <translation>Очистить корзину</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="45"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="567"/>
        <source>Trash older than:</source>
        <translation>Корзина старше чем:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="103"/>
        <location filename="../mainwindow.ui" line="294"/>
        <location filename="../mainwindow.ui" line="438"/>
        <location filename="../mainwindow.cpp" line="962"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="570"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="584"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="592"/>
        <source> days</source>
        <translation> дн.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="58"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="568"/>
        <source>All users</source>
        <translation>Все пользователи</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="90"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="569"/>
        <source>Selected user</source>
        <translation>Выбранный пользователь</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="210"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="579"/>
        <source>Clear APT Cache</source>
        <translation>Очистить кэш APT</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="580"/>
        <source>Old files</source>
        <translation>Старые файлы</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="244"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="581"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="605"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="608"/>
        <source>Graphical Tool for Analyzing Disk Usage</source>
        <translation>Графический инструмент анализа дискового пространства</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="617"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="609"/>
        <source>Run Disk Usage Analyzer</source>
        <translation>Запустить анализатор дискового пространства</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="141"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="573"/>
        <source>Schedule</source>
        <translation>Расписание</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="153"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="574"/>
        <source>No automatic clean</source>
        <translation>Без автоматической очистки</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="575"/>
        <source>At reboot</source>
        <translation>При перезагрузке</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="167"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="576"/>
        <source>Daily</source>
        <translation>Ежедневно</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="174"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="577"/>
        <source>Weekly</source>
        <translation>Еженедельно</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="578"/>
        <source>Monthly</source>
        <translation>Ежемесячно</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="467"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="594"/>
        <source>Free Disk Space for User</source>
        <translation>Освободить дисковое пространство для пользователя</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="479"/>
        <location filename="../mainwindow.ui" line="495"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="596"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="600"/>
        <source>Select user to repair</source>
        <translation>Выберите пользователя для восстановления</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="482"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="598"/>
        <source>Select user:</source>
        <translation>Выберите пользователя:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="263"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="582"/>
        <source>Delete Logs</source>
        <translation>Удалить журналы</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="278"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="583"/>
        <source>All logs</source>
        <translation>Все журналы</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="339"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="587"/>
        <source>Old logs</source>
        <translation>Старые журналы</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="326"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="586"/>
        <source>Logs older than:</source>
        <translation>Журналы старше чем:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="551"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="605"/>
        <source>Remove unused WiFi drivers</source>
        <translation>Удалить неиспользуемые драйверы Wi-Fi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="570"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="606"/>
        <source>List and select kernels to remove</source>
        <translation>Список и выбор ядер для удаления</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="125"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="571"/>
        <source>Clean Flatpak</source>
        <translation>Очистить Flatpak</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="572"/>
        <source>Remove unused runtimes</source>
        <translation>Удалить неиспользуемые среды выполнения</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="364"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="588"/>
        <source>Clean Folders</source>
        <translation>Очистить папки</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="428"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="591"/>
        <source>Not accessed for:</source>
        <translation>Не использовались в течение:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="376"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="589"/>
        <source>Cache</source>
        <translation>Кэш</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="451"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="593"/>
        <source>All (potentially dangerous)</source>
        <translation>Все (потенциально опасно)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="405"/>
        <location filename="../build/mx-cleanup_autogen/include/ui_mainwindow.h" line="590"/>
        <source>Thumbnails</source>
        <translation>Эскизы</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="143"/>
        <source>Remove Manuals</source>
        <translation>Удалить руководства</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="143"/>
        <source>No manuals to remove.</source>
        <translation>Нет руководств для удаления.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="156"/>
        <location filename="../mainwindow.cpp" line="163"/>
        <source>Removing packages, please wait</source>
        <translation>Удаление пакетов, пожалуйста, подождите</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="962"/>
        <source> day</source>
        <translation> дн.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="149"/>
        <location filename="../mainwindow.cpp" line="981"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="222"/>
        <source>Clean pacman cache</source>
        <translation>Очистить кэш Pacman</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="149"/>
        <location filename="../mainwindow.cpp" line="981"/>
        <source>Failed to elevate privileges</source>
        <translation>Не удалось повысить привилегии</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1033"/>
        <location filename="../mainwindow.cpp" line="1055"/>
        <source>Cache cleanup</source>
        <translation>Очистка кэша</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1085"/>
        <location filename="../mainwindow.cpp" line="1089"/>
        <source>Thumbnail cleanup</source>
        <translation>Очистка эскизов</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1110"/>
        <location filename="../mainwindow.cpp" line="1128"/>
        <source>Flatpak cleanup</source>
        <translation>Очистка Flatpak</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1164"/>
        <source>Package cache cleanup</source>
        <translation>Очистка кэша пакетов</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1190"/>
        <source>Package purge</source>
        <translation>Очистка пакетов</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1216"/>
        <source>Log cleanup</source>
        <translation>Очистка журналов</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1253"/>
        <location filename="../mainwindow.cpp" line="1257"/>
        <source>Trash cleanup</source>
        <translation>Очистка корзины</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1307"/>
        <location filename="../mainwindow.cpp" line="1321"/>
        <source>Save cleanup schedule</source>
        <translation>Сохранить расписание очистки</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1324"/>
        <source>Remove previous cleanup schedule</source>
        <translation>Удалить предыдущее расписание очистки</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1328"/>
        <source>Save settings</source>
        <translation>Сохранить настройки</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1344"/>
        <source>Some cleanup steps failed</source>
        <translation>Некоторые шаги очистки завершились ошибкой</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1345"/>
        <source>%1 MiB were freed, but the following steps failed:</source>
        <translation>Освобождено %1 МиБ, но следующие шаги завершились ошибкой:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1348"/>
        <location filename="../mainwindow.cpp" line="1350"/>
        <source>Done</source>
        <translation>Готово</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1348"/>
        <source>Cleanup script will run at reboot</source>
        <translation>Скрипт очистки будет запущен при перезагрузке</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1351"/>
        <source>Cleanup command done</source>
        <translation>Команда очистки выполнена</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1351"/>
        <source>%1 MiB were freed</source>
        <translation>Освобождено %1 МиБ</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1360"/>
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1361"/>
        <source>Version: </source>
        <translation>Версия: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1363"/>
        <source>Quick and safe removal of old files</source>
        <translation>Быстрое и безопасное удаление старых файлов</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1365"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Авторское право (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1366"/>
        <source>%1 License</source>
        <translation>Лицензия %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1373"/>
        <source>%1 Help</source>
        <translation>Справка %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1485"/>
        <source>No privilege elevation tool is available</source>
        <translation>Нет доступного средства повышения привилегий</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1498"/>
        <source>Failed to start the helper process</source>
        <translation>Не удалось запустить вспомогательный процесс</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1521"/>
        <source>Operation timed out</source>
        <translation>Время операции истекло</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1616"/>
        <source>Kernel currently in use: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Используемое ядро: &lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1619"/>
        <source>Remove selected</source>
        <translation>Удалить выбранное</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1624"/>
        <source>Similar kernels that can be removed:</source>
        <translation>Похожие ядра, которые можно удалить:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1625"/>
        <source>Other kernels that can be removed:</source>
        <translation>Другие ядра, которые можно удалить:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1628"/>
        <source>&lt;b&gt;Nothing to remove.&lt;/b&gt; Cannot remove kernel in use.</source>
        <translation>&lt;b&gt;Нечего удалять.&lt;/b&gt; Нельзя удалить используемое ядро.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1672"/>
        <location filename="../mainwindow.cpp" line="1685"/>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1672"/>
        <source>No unused network drivers found to remove.</source>
        <translation>Неиспользуемых сетевых драйверов для удаления не найдено.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1685"/>
        <source>No valid packages found to remove.</source>
        <translation>Подходящих пакетов для удаления не найдено.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>Не удалось загрузить %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="94"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="95"/>
        <location filename="../about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Список изменений</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>Не удалось загрузить список изменений.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="51"/>
        <location filename="../about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="70"/>
        <source>Quick safe removal of old files</source>
        <translation>Быстрое безопасное удаление старых файлов</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="99"/>
        <location filename="../main.cpp" line="107"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="100"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Вы вошли в систему как root. Пожалуйста, выйдите и войдите как обычный пользователь для использования этой программы.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>You must run this program with admin access.</source>
        <translation>Вы должны запустить эту программу с правами администратора.</translation>
    </message>
</context>
</TS>